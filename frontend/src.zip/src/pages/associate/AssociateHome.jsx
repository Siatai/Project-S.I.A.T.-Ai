import React from "react";

export default function AssociateHome() {
  return (
    <div style={{ color: "#E5E7EB", padding: "20px" }}>
      <h2>🤝 Associate Dashboard</h2>
      <p style={{ marginTop: "10px" }}>
        Welcome, Associate. Here you can track referrals, earnings, and withdrawals.
      </p>
    </div>
  );
}
