import React from "react";

export default function Commissions() {
  // mock data
  const commissions = [
    { id: 1, investor: "user1@email.com", profit: 200, commission: 20, date: "2025-09-01" },
    { id: 2, investor: "user2@email.com", profit: 300, commission: 30, date: "2025-09-04" },
  ];

  return (
    <div style={{ color: "#E5E7EB" }}>
      <h2>Referral Commissions</h2>
      <table style={{ width: "100%", marginTop: "20px", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ backgroundColor: "#1E293B" }}>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Investor</th>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Profit</th>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Commission</th>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Date</th>
          </tr>
        </thead>
        <tbody>
          {commissions.map((c) => (
            <tr key={c.id}>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>{c.investor}</td>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>${c.profit}</td>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>${c.commission}</td>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>{c.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
