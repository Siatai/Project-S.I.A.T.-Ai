import React, { useEffect, useState } from "react";
import axios from "axios";
import AssociateNavbar from "./AssociateNavbar"; // ✅ Navbar

export default function Commissions() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(null);

  const API = "https://project-s-i-a-t-ai.onrender.com";
  const token = localStorage.getItem("token");

  // Decode email from JWT
  let email = "";
  if (token) {
    try {
      email = JSON.parse(atob(token.split(".")[1])).email;
    } catch (e) {
      console.error("Error decoding token:", e);
    }
  }

  // Fetch referral income summary
  useEffect(() => {
    const fetchSummary = async () => {
      try {
        setLoading(true);
        const res = await axios.get(`${API}/get-referral-income`, {
          params: { email },
          headers: { Authorization: `Bearer ${token}` },
        });
        setSummary(res.data);
      } catch (err) {
        console.error("Error fetching referral income:", err);
      } finally {
        setLoading(false);
      }
    };

    if (email) fetchSummary();
  }, [email, token]);

  // Group details by date
  const groupedByDate = summary
    ? summary.details.reduce((acc, d) => {
        if (!acc[d.date]) acc[d.date] = [];
        acc[d.date].push(d);
        return acc;
      }, {})
    : {};

  if (loading) return <p style={{ color: "#E5E7EB" }}>Loading commissions...</p>;
  if (!summary)
    return <p style={{ color: "#E5E7EB" }}>No commission data available.</p>;

  return (
    <div style={pageWrapper}>
      <AssociateNavbar /> {/* ✅ Fixed Navbar */}

      <main style={mainContent}>
        <h2
          style={{
            marginBottom: "20px",
            fontFamily: "Orbitron, sans-serif",
            color: "#17E8E5",
          }}
        >
          My Commissions
        </h2>

        {/* Summary Cards */}
        <div
          style={{
            display: "flex",
            gap: "20px",
            marginBottom: "20px",
            flexWrap: "wrap",
          }}
        >
          {[
            { label: "Total Earnings", value: summary.total, color: "#E5E7EB" },
            { label: "Withdrawn", value: summary.withdrawn, color: "#E5E7EB" },
            {
              label: "Withdrawable",
              value: summary.withdrawable,
              color: "#17E8E5",
            },
          ].map((card, i) => (
            <div key={i} style={cardStyle}>
              <h3 style={{ fontSize: "15px", fontWeight: "600", marginBottom: "6px" }}>
                {card.label}
              </h3>
              <p
                style={{
                  fontSize: "22px",
                  fontWeight: "700",
                  color: card.color,
                }}
              >
                ${card.value}
              </p>
            </div>
          ))}
        </div>

        {/* Referral Details grouped by date */}
        <h3 style={{ marginTop: "30px", marginBottom: "12px", color: "#17E8E5" }}>
          Referral Earnings by Date
        </h3>
        <div style={tableWrapper}>
          <table
            style={{ width: "100%", borderCollapse: "separate", borderSpacing: "0 12px" }}
          >
            <thead>
              <tr style={{ background: "rgba(31,41,55,0.9)" }}>
                {["Date", "Total Earnings"].map((h, i) => (
                  <th key={i} style={thStyle}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Object.entries(groupedByDate).map(([date, records], i) => {
                const totalForDay = records.reduce(
                  (sum, r) => sum + r.commission,
                  0
                );
                return (
                  <tr key={i} style={rowStyle}>
                    <td style={{ ...tdStyle, borderLeft: "4px solid #17E8E5" }}>
                      {date}
                    </td>
                    <td style={{ ...tdStyle, display: "flex", alignItems: "center", gap: "8px" }}>
                      <span
                        onClick={() => setSelectedDate({ date, records })}
                        style={viewBtn}
                        title="View Details"
                      >
                        🔍
                      </span>
                      <span style={{ color: "#17E8E5", fontWeight: "600" }}>
                        ${totalForDay.toFixed(2)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Popup for details */}
        {selectedDate && (
          <div style={popupOverlay} onClick={() => setSelectedDate(null)}>
            <div style={popupBox} onClick={(e) => e.stopPropagation()}>
              <h3 style={{ marginBottom: "15px", color: "#17E8E5" }}>
                Details for {selectedDate.date}
              </h3>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: "rgba(55,65,81,0.8)" }}>
                    {["Referred User", "Investment", "Earning"].map((h, i) => (
                      <th key={i} style={thStyle}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {selectedDate.records.map((r, idx) => (
                    <tr key={idx} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                      <td style={tdStyle}>{r.name || r.investor}</td>
                      <td style={tdStyle}>${r.roi_source}</td>
                      <td style={{ ...tdStyle, color: "#17E8E5", fontWeight: "600" }}>
                        ${r.commission}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button onClick={() => setSelectedDate(null)} style={btnRed}>
                Close
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

/* === Styles === */
const pageWrapper = {
  background: "#0f172a",
  minHeight: "100vh",
  width: "100%",
  overflowX: "hidden",
};

const mainContent = {
  padding: "20px",
  marginTop: "80px", // ✅ offset header
  marginBottom: "70px", // ✅ offset footer
};

const cardStyle = {
  flex: "1",
  minWidth: "220px",
  padding: "18px",
  borderRadius: "12px",
  background: "rgba(17,24,39,0.8)",
  backdropFilter: "blur(8px)",
  boxShadow: "0 0 15px rgba(23,232,229,0.2)",
};

const tableWrapper = {
  borderRadius: "12px",
  overflowX: "auto",
  background: "rgba(17,24,39,0.8)",
  boxShadow: "0 0 12px rgba(23,232,229,0.15)",
};

const thStyle = {
  padding: "12px",
  textAlign: "left",
  fontSize: "14px",
  color: "#9CA3AF",
  fontWeight: "600",
};

const rowStyle = {
  background: "rgba(15,23,42,0.9)",
  boxShadow: "0 0 10px rgba(23,232,229,0.3)",
  borderRadius: "8px",
};

const tdStyle = {
  padding: "12px",
  fontSize: "14px",
  color: "#E5E7EB",
  fontFamily: "Inter, sans-serif",
};

const viewBtn = {
  cursor: "pointer",
  fontSize: "16px",
  color: "#38BDF8",
  textShadow: "0 0 8px rgba(23,232,229,0.6)",
};

const btnRed = {
  marginTop: "15px",
  padding: "8px 16px",
  border: "none",
  borderRadius: "8px",
  background: "#EF4444",
  color: "#fff",
  fontWeight: "600",
  cursor: "pointer",
};

const popupOverlay = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100%",
  height: "100%",
  background: "rgba(0,0,0,0.6)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 1000,
};

const popupBox = {
  background: "rgba(17,24,39,0.95)",
  padding: "25px",
  borderRadius: "12px",
  maxWidth: "600px",
  width: "100%",
  boxShadow: "0 0 20px rgba(23,232,229,0.3)",
};
