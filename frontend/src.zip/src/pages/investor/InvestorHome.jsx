import React, { useState } from "react";
import axios from "axios";

export default function InvestorHome() {
  const [applied, setApplied] = useState(false);
  const API = "http://127.0.0.1:8000/api";

  const applyForAssociate = async () => {
    try {
      const token = localStorage.getItem("token");
      await axios.post(`${API}/request-associate`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setApplied(true);
      alert("Request sent to admin for approval.");
    } catch (err) {
      console.error(err);
      alert(err?.response?.data?.detail || "Something went wrong");
    }
  };

  return (
    <div style={{ color: "#E5E7EB" }}>
      <h2>Welcome Investor</h2>
      <p style={{ marginTop: 10 }}>You can deposit funds, withdraw profits, and track your ROI here.</p>

      {!applied ? (
        <button onClick={applyForAssociate}
          style={{ marginTop: 20, padding: "10px 20px", border: "none", borderRadius: 6, background: "#3B82F6", color: "#fff", cursor: "pointer" }}>
          Apply to become Associate
        </button>
      ) : (
        <p style={{ marginTop: 20, color: "#FACC15" }}>⏳ Pending approval from Admin...</p>
      )}
    </div>
  );
}
