import React from "react";

export default function WithdrawApprovals() {
  return <h2 style={{ color: "#E5E7EB" }}>Withdrawal Approvals</h2>;
}
