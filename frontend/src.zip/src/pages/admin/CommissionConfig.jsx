import React from "react";

export default function CommissionConfig() {
  return <h2 style={{ color: "#E5E7EB" }}>Commission Configuration</h2>;
}
