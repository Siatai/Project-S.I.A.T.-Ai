import React from "react";

export default function AdminHome() {
  return (
    <div style={{ color: "#E5E7EB", padding: "20px" }}>
      <h2>👑 Admin Dashboard</h2>
      <p style={{ marginTop: "10px" }}>
        Welcome, Admin. Here you will manage users, approve associates, and configure ROI.
      </p>
    </div>
  );
}
