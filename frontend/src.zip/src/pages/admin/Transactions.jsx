import React from "react";

export default function Transactions() {
  return <h2 style={{ color: "#E5E7EB" }}>All Transactions</h2>;
}
