import React from "react";

export default function Users() {
  return <h2 style={{ color: "#E5E7EB" }}>Manage Users</h2>;
}
