import React from "react";

export default function ROIConfig() {
  return <h2 style={{ color: "#E5E7EB" }}>ROI Configuration</h2>;
}
