import React, { useState } from "react";

export default function Wallet() {
  const [wallet, setWallet] = useState("");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    // call backend API: save wallet
    setSaved(true);
  };

  return (
    <div style={{ color: "#E5E7EB" }}>
      <h2>Crypto Wallet</h2>
      <p style={{ marginTop: "10px" }}>
        Please set your TRC20 USDT wallet address. This will be used for all withdrawals.
      </p>

      <input
        value={wallet}
        onChange={(e) => setWallet(e.target.value)}
        placeholder="Enter your TRC20 wallet address"
        style={{ marginTop: "15px", width: "60%", padding: "10px", borderRadius: "6px" }}
      />
      <button
        onClick={handleSave}
        style={{ marginLeft: "10px", padding: "10px 20px", border: "none", borderRadius: "6px",
          background: "#3B82F6", color: "#fff", cursor: "pointer" }}
      >
        Save
      </button>

      {saved && (
        <p style={{ marginTop: "15px", color: "#22c55e" }}>
          ✅ Wallet saved successfully!
        </p>
      )}
    </div>
  );
}
