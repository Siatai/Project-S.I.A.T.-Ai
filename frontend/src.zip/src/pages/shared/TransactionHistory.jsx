import React, { useState } from "react";

export default function TransactionHistory() {
  const [filter, setFilter] = useState("all");

  // mock transactions
  const transactions = [
    { id: 1, type: "Deposit", amount: 500, date: "2025-09-01" },
    { id: 2, type: "Withdrawal", amount: 200, date: "2025-09-03" },
    { id: 3, type: "Deposit", amount: 300, date: "2025-09-04" },
  ];

  const filtered = filter === "all" ? transactions : transactions.filter(t => t.type === filter);

  return (
    <div style={{ color: "#E5E7EB" }}>
      <h2>Transaction History</h2>

      <div style={{ marginTop: "15px", marginBottom: "15px" }}>
        <button onClick={() => setFilter("all")} style={{ marginRight: "10px" }}>All</button>
        <button onClick={() => setFilter("Deposit")} style={{ marginRight: "10px" }}>Deposits</button>
        <button onClick={() => setFilter("Withdrawal")}>Withdrawals</button>
      </div>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ backgroundColor: "#1E293B" }}>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>ID</th>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Type</th>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Amount</th>
            <th style={{ padding: "10px", border: "1px solid #2D3748" }}>Date</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((tx) => (
            <tr key={tx.id}>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>{tx.id}</td>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>{tx.type}</td>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>${tx.amount}</td>
              <td style={{ padding: "10px", border: "1px solid #2D3748" }}>{tx.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
