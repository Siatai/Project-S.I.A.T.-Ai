import React from "react";
export default function Deposit() {
  return <h2 style={{ color: "#E5E7EB" }}>Deposit Page</h2>;
}
