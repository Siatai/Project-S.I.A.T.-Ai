import React, { useState } from "react";

export default function Withdrawal() {
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState("form"); // form → otp → success

  // mock balance
  const balance = 1000;
  const feePercent = 5;
  const fee = (balance * feePercent) / 100;
  const net = balance - fee;

  const handleWithdraw = () => {
    setStep("otp");
  };

  const handleOtpConfirm = () => {
    // call backend API here with OTP + withdrawal request
    setStep("success");
  };

  return (
    <div style={{ color: "#E5E7EB" }}>
      <h2>Withdrawal</h2>

      {step === "form" && (
        <div style={{ marginTop: "20px" }}>
          <p>Available Balance: ${balance}</p>
          <p>Withdrawal Fee ({feePercent}%): ${fee}</p>
          <p><strong>Net Amount:</strong> ${net}</p>

          <button
            onClick={handleWithdraw}
            style={{ marginTop: "20px", padding: "10px 20px", border: "none",
              borderRadius: "6px", background: "#3B82F6", color: "#fff", cursor: "pointer" }}
          >
            Withdraw Full Balance
          </button>
        </div>
      )}

      {step === "otp" && (
        <div style={{ marginTop: "20px" }}>
          <p>Enter OTP sent to your email:</p>
          <input
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            style={{ padding: "8px", borderRadius: "4px", marginRight: "10px" }}
          />
          <button
            onClick={handleOtpConfirm}
            style={{ padding: "8px 16px", border: "none", borderRadius: "6px",
              background: "#3B82F6", color: "#fff", cursor: "pointer" }}
          >
            Confirm
          </button>
        </div>
      )}

      {step === "success" && (
        <div style={{ marginTop: "20px", color: "#22c55e" }}>
          ✅ Withdrawal request submitted successfully! Awaiting admin approval.
        </div>
      )}
    </div>
  );
}
