import React, { useEffect, useState } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import axios from "axios";

export default function DashboardLayout({ role }) {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const API = "http://127.0.0.1:8000/api";

  // Fetch current user on mount
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) return;

        const res = await axios.get(`${API}/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(res.data);
      } catch (err) {
        console.error("Error fetching user:", err);
        // If token invalid, force logout
        handleLogout();
      }
    };
    fetchUser();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sidebar menu items based on role
  const investorMenu = [
    { label: "Home", path: "/investor" },
    { label: "Deposit", path: "/investor/deposit" },
    { label: "Withdrawal", path: "/investor/withdrawal" },
    { label: "Wallet", path: "/investor/wallet" },
    { label: "Transactions", path: "/investor/history" },
  ];

  const associateMenu = [
    { label: "Commissions", path: "/associate/commissions" },
    { label: "Withdrawal", path: "/associate/withdrawal" },
    { label: "Wallet", path: "/associate/wallet" },
    { label: "Transactions", path: "/associate/history" },
  ];

  const adminMenu = [
    { label: "Users", path: "/admin/users" },
    { label: "ROI Config", path: "/admin/roi" },
    { label: "Commission Config", path: "/admin/commission" },
    { label: "Withdrawal Approvals", path: "/admin/approvals" },
    { label: "Transactions", path: "/admin/transactions" },
  ];

  let menu = investorMenu;
  if (role === "associate") menu = associateMenu;
  if (role === "admin") menu = adminMenu;

  // Handle logout → go to Landing "/"
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/");
  };

  return (
    <div style={{ display: "flex", height: "100vh", background: "#111827" }}>
      {/* Sidebar */}
      <aside
        style={{
          width: "220px",
          background: "#1F2937",
          padding: "20px",
          color: "#E5E7EB",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
        }}
      >
        <div>
          <h2 style={{ fontSize: "18px", marginBottom: "10px" }}>
            {role.charAt(0).toUpperCase() + role.slice(1)} Dashboard
          </h2>

          {user && (
            <p style={{ marginBottom: "20px", fontSize: "14px", color: "#9CA3AF" }}>
              Welcome, <strong>{user.name}</strong>
            </p>
          )}

          <nav>
            {menu.map((item) => (
              <div key={item.path} style={{ marginBottom: "12px" }}>
                <Link
                  to={item.path}
                  style={{
                    textDecoration: "none",
                    color: "#E5E7EB",
                    fontSize: "14px",
                  }}
                >
                  {item.label}
                </Link>
              </div>
            ))}
          </nav>
        </div>

        {/* Logout button */}
        <button
          onClick={handleLogout}
          style={{
            marginTop: "20px",
            padding: "10px",
            border: "none",
            borderRadius: "6px",
            background: "#EF4444",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          Logout
        </button>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, padding: "20px", color: "#E5E7EB" }}>
        <Outlet />
      </main>
    </div>
  );
}
