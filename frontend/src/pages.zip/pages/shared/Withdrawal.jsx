import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";
import InvestorNavbar from "../investor/Navbar"; // ✅ Investor Navbar

export default function Withdrawal() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [withdrawing, setWithdrawing] = useState(false);
  const [message, setMessage] = useState(null);

  const API = "https://project-s-i-a-t-ai.onrender.com";
  const token = localStorage.getItem("token");

  // 🔹 Apply global dark background + reset body (no bleed)
  useEffect(() => {
    document.body.style.margin = "0";
    document.body.style.padding = "0";
    document.body.style.background = "var(--fx-hero)";
    document.body.style.overflowX = "hidden";
  }, []);

  // 🔹 Fetch wallet summary
  const fetchSummary = useCallback(async () => {
    try {
      setLoading(true);
      const res = await axios.get(`${API}/wallet/summary`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = res.data;

      const settled = data.withdrawals.filter((w) => w.status === "settled");
      const pending = data.withdrawals.filter((w) => w.status === "pending");

      const totalEarnings =
        (data.wallet_balance || 0) +
        data.withdrawals.reduce((sum, w) => sum + (w.amount || 0), 0);

      const withdrawn = settled.reduce(
        (sum, w) => sum + (w.final_amount || 0),
        0
      );
      const pendingAmt = pending.reduce((sum, w) => sum + (w.amount || 0), 0);
      const deductions = settled.reduce(
        (sum, w) => sum + ((w.amount || 0) - (w.final_amount || 0)),
        0
      );

      setSummary({
        wallet_balance: data.wallet_balance || 0,
        total: totalEarnings,
        withdrawn,
        pending: pendingAmt,
        withdrawable: data.wallet_balance || 0,
        deductions,
        withdrawals: data.withdrawals || [],
      });
    } catch (err) {
      console.error("Error fetching wallet summary:", err);
    } finally {
      setLoading(false);
    }
  }, [API, token]);

  useEffect(() => {
    if (token) fetchSummary();
  }, [token, fetchSummary]);

  // 🔹 Request OTP (with Sat/Sun + $20 check)
  const requestOtp = async () => {
    if (summary.withdrawable < 20) {
      return setMessage({ type: "error", text: "Minimum withdrawal is $20." });
    }
    const today = new Date().getDay(); // 0=Sunday, 6=Saturday
    if (today !== 0 && today !== 1 && today !== 2 && today !== 3 && today !== 4 && today !== 5 && today !== 6) {
      return setMessage({
        type: "error",
        text: "Withdrawals are allowed only on Saturday and Sunday.",
      });
    }
    try {
      await axios.post(
        `${API}/send-otp-withdrawal`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setOtpSent(true);
      setMessage({ type: "success", text: "OTP sent to your email." });
    } catch (err) {
      setMessage({
        type: "error",
        text: err?.response?.data?.detail || "Failed to send OTP",
      });
    }
  };

  // 🔹 Confirm withdrawal
  const confirmWithdrawal = async () => {
    try {
      setWithdrawing(true);
      const res = await axios.post(
        `${API}/request-withdrawal`,
        { otp },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMessage({ type: "success", text: res.data.message });
      setOtp("");
      setOtpSent(false);
      fetchSummary();
    } catch (err) {
      setMessage({
        type: "error",
        text: err?.response?.data?.detail || "Withdrawal failed",
      });
    } finally {
      setWithdrawing(false);
    }
  };

  if (loading) return <p style={{ color: "var(--fx-ink)" }}>Loading...</p>;

  return (
    <div style={pageWrapper}>
      <InvestorNavbar />

      <div style={wrapper}>
        <h2 style={headerTitle}>Withdrawal</h2>

        {/* 🔹 Total Earnings Card */}
        <div style={highlightCard}>
          <h3 style={cardTitle}>Total Earnings</h3>
          <p style={bigValue}>${summary.total.toFixed(2)}</p>
        </div>

        {/* 🔹 Main Balance Card */}
        <div style={mainCard}>
          <h3 style={cardTitle}>Withdrawable Balance</h3>
          <p style={bigValueTeal}>${summary.withdrawable.toFixed(2)}</p>

          <div style={miniRows}>
            <div style={miniRow}>
              <span>Withdrawn</span>
              <strong>${summary.withdrawn.toFixed(2)}</strong>
            </div>
            <div style={miniRow}>
              <span>Pending</span>
              <strong style={{ color: "var(--fx-gold)" }}>
                ${summary.pending.toFixed(2)}
              </strong>
            </div>
            <div style={miniRow}>
              <span>Deductions</span>
              <strong style={{ color: "var(--fx-danger)" }}>
                -${summary.deductions.toFixed(2)}
              </strong>
            </div>
          </div>

          {/* 🔹 Glow line below Wallet */}
          <div style={glowLine} />

          {message && <div style={msgBox(message.type)}>{message.text}</div>}

          {!otpSent ? (
            <button style={btnTeal} onClick={requestOtp}>
              Request Withdrawal
            </button>
          ) : (
            <div style={{ marginTop: "20px" }}>
              <input
                type="text"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                style={inputStyle}
              />
              <button
                style={btnTeal}
                onClick={confirmWithdrawal}
                disabled={!otp}
              >
                {withdrawing ? "Submitting..." : "Confirm Withdrawal"}
              </button>
            </div>
          )}
        </div>

        {/* 🔹 Withdrawals History */}
        <h3 style={subHeader}>Withdrawal History</h3>
        <div style={tableWrapper}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "rgba(8, 10, 20, 0.7)" }}>
                {["Date", "Amount", "Status"].map((h, i) => (
                  <th key={i} style={thStyle}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {summary.withdrawals.map((w, idx) => (
                <tr key={idx} style={rowStyle}>
                  <td style={tdStyle}>
                    {new Date(w.timestamp).toLocaleString()}
                  </td>
                  <td style={tdStyle}>${w.final_amount}</td>
                  <td
                    style={{
                      ...tdStyle,
                      color:
                        w.status === "pending"
                          ? "var(--fx-gold)"
                          : w.status === "settled"
                          ? "var(--fx-accent)"
                          : "var(--fx-danger)",
                      fontWeight: "600",
                    }}
                  >
                    {w.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* === Styles === */
const pageWrapper = {
  background: "transparent", // 🔹 dark background
  color: "var(--fx-ink)",
  minHeight: "100vh",
  display: "flex",
  flexDirection: "column",
};

const wrapper = { padding: "20px", marginTop: "80px", marginBottom: "70px" };
const headerTitle = {
  fontFamily: "var(--fx-font-display)",
  color: "var(--fx-accent)",
  marginBottom: "20px",
};
const highlightCard = {
  background: "var(--fx-card-strong)",
  padding: "20px",
  borderRadius: "14px",
  textAlign: "center",
  marginBottom: "20px",
  border: "1px solid var(--fx-border)",
  boxShadow: "var(--fx-shadow)",
};
const mainCard = {
  background: "var(--fx-card)",
  padding: "20px",
  borderRadius: "14px",
  marginBottom: "30px",
  border: "1px solid var(--fx-border)",
  boxShadow: "var(--fx-shadow)",
  textAlign: "center",
};
const cardTitle = { fontSize: "15px", color: "var(--fx-muted)", marginBottom: "10px" };
const bigValue = { fontSize: "28px", fontWeight: "700", color: "var(--fx-ink)" };
const bigValueTeal = { fontSize: "26px", fontWeight: "700", color: "var(--fx-accent)" };

const miniRows = { marginTop: "15px", textAlign: "left" };
const miniRow = {
  display: "flex",
  justifyContent: "space-between",
  marginBottom: "6px",
  fontSize: "14px",
  color: "var(--fx-ink)",
};

const glowLine = {
  height: "2px",
  background: "linear-gradient(90deg, transparent, var(--fx-accent), transparent)",
  boxShadow: "0 0 10px var(--fx-accent)",
  margin: "16px 0 20px",
};

const btnTeal = {
  marginTop: "15px",
  padding: "12px",
  border: "none",
  borderRadius: "8px",
  fontWeight: "700",
  background: "linear-gradient(135deg, var(--fx-button), var(--fx-button-2))",
  color: "var(--fx-bg)",
  cursor: "pointer",
  width: "100%",
  maxWidth: "320px",
};
const inputStyle = {
  width: "100%",
  maxWidth: "320px",
  padding: "12px",
  borderRadius: "8px",
  border: "1px solid var(--fx-border)",
  background: "rgba(8, 10, 20, 0.6)",
  color: "var(--fx-ink)",
  marginBottom: "12px",
};
const msgBox = (type) => ({
  marginTop: "10px",
  padding: "10px",
  borderRadius: "8px",
  background:
    type === "error" ? "rgba(239,68,68,0.15)" : "rgba(16,185,129,0.15)",
  border: `1px solid ${type === "error" ? "var(--fx-danger)" : "var(--fx-success)"}`,
  color: type === "error" ? "var(--fx-danger)" : "var(--fx-success-2)",
});
const subHeader = {
  marginBottom: "12px",
  marginTop: "20px",
  color: "var(--fx-accent)",
  fontWeight: "600",
};
const tableWrapper = {
  borderRadius: "12px",
  overflowX: "auto",
  background: "var(--fx-card)",
  border: "1px solid var(--fx-border)",
  boxShadow: "var(--fx-shadow)",
};
const thStyle = {
  padding: "12px",
  textAlign: "left",
  fontSize: "14px",
  color: "var(--fx-muted)",
};
const rowStyle = { borderBottom: "1px solid var(--fx-border)" };
const tdStyle = {
  padding: "12px",
  fontSize: "14px",
  color: "var(--fx-ink)",
  fontFamily: "var(--fx-font-body)",
};
